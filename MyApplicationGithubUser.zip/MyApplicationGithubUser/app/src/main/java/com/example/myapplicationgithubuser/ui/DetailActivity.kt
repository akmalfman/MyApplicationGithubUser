package com.example.myapplicationgithubuser.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.myapplicationgithubuser.data.response.DetailUserResponse
import com.example.myapplicationgithubuser.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var sectionsPagerAdapter: SectionsPagerAdapter
    private val detailViewModel by viewModels<DetailViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sectionsPagerAdapter = SectionsPagerAdapter(this)
        sectionsPagerAdapter.username = intent.getStringExtra("user_login").toString()

        val viewPager: ViewPager2 = binding.viewPager
        viewPager.adapter = sectionsPagerAdapter

        val tabs: TabLayout = binding.tabs

        TabLayoutMediator(tabs, viewPager) { tab, position ->
            if (position == 0) {
                tab.text = "Follower"
            } else {
                tab.text = "Following"
            }
        }.attach()

        supportActionBar?.hide()

        val userLogin = intent.getStringExtra("user_login")

        if (userLogin != null) {
            detailViewModel.findDetailUser(userLogin)
            detailViewModel.findFollowers(userLogin)
        }

        detailViewModel.listDetailUser.observe(this) { listDetailUser ->
            setDetailUserData(listDetailUser)
        }

        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }

    }

    private fun setDetailUserData(listDetailUser: DetailUserResponse) {
        binding.tvName.text = listDetailUser.name
        binding.tvLogin.text = listDetailUser.login
        Glide.with(this@DetailActivity)
            .load("${listDetailUser.avatarUrl}?v=4")
            .into(binding.imgItemUser)
        binding.tvFollowers.text = listDetailUser.followers.toString()
        binding.tvFollowing.text = listDetailUser.following.toString()
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}